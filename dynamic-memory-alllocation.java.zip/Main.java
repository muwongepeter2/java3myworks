//in this program we see how to allocate memory dynamic
// THE PROGRAM IS A SIMPLE energy bill calculator.

import java.util.Scanner;
public class Dynamicmemory
{
public static void main(String[]args)
{
    int costperunit=740;
    float units_consumed_daily, time_in_hours, daily_average_consumption;
    float daily_average_consumption_in_RS ,daily_power_usage_in_watts, monthly_bill;
    
    Scanner electro = new Scanner(System.in);
    
    System.out.println("enter average daily load size in watts i.e combined load declared=");
    daily_power_usage_in_watts = electro.nextInt();
    System.out.println("\n");
    
    System.out.println("for how much time do you use power daily I.e in hours =");
    time_in_hours  = electro.nextInt();                      // time is dymically allocated memory i.e after scanning 
    
    while(time_in_hours>24||time_in_hours<1)
    {System.out.println("wrong time entered,please enter correct time");
        
        time_in_hours  = electro.nextInt();
    }
    
    
    //                 code for computation of monthly bill
    
                   // I=v/i
    
    daily_average_consumption = daily_power_usage_in_watts/ 1000;    // converting to kilowatt hours i.e may be of intrest to client
   
    
   units_consumed_daily = daily_average_consumption * time_in_hours; //  energy
   daily_average_consumption = units_consumed_daily * costperunit;
   monthly_bill    = daily_average_consumption * 30;
   
    System.out.println("\n");
    System.out.println("\n");
   
   System.out.println("Dear sir your average daily units consumed  ="+units_consumed_daily + "KWh");
   
   System.out.println(" average daily consumption in rupees   ="+ daily_average_consumption + "RS");
   
   System.out.println(" Your bill for the month is ="+monthly_bill + "RS");// concotination
   System.out.println("\n");
   System.out.println("\n");
 
   
   
   
   if (monthly_bill > 100000){
       System.out.println("you qualify for energy rebate from BREAVERS AUTOMATIONS LTD KL-UNIVERSITY");
    }
    
   else if (monthly_bill < 1000){
       System.out.println("consider using electricity for cooking to attain a enjoy a cheap tarrif and save enviroment KL-UNIVERSITY");
    }
       else
       {System.out.println("Pay your bills timely , thank you");
           System.out.println("Powered by Breavers AUTOMATIONS KL-UNIVERSITY");
           
       }
    }

}

