

//java program to perform implicit conversion to different data types

import java.util.Scanner;
public class IMPLICITCONVERSION
{
    public static void main(String args[])
    {
        
    byte k=111;
    short b=k;
    int m;
    m=b+223545;
    
    long y=m*3334;
    float r;
    r=y/311232;
    double t;
    
      t=r/50006;    
    System.out.println("byte data ="+k);
    System.out.println("\n");
    
    System.out.println("short data ="+b);
    System.out.println("\n");
    
    System.out.println("int data ="+m);
    System.out.println("\n");
    
    System.out.println("long data ="+y);
    System.out.println("\n");
    
    System.out.println("float data ="+r);
    System.out.println("\n");
    
    System.out.println("double data ="+t);
    System.out.println("\n");

    
        
}
}