

//Java programe TO FIND AVERGE OF +VE AND -VE NOS,scan endless inputs,entering zero terminates scanning input

import java.util.Scanner;
public class PRACTICAL1B
{
    public static void main(String args[])
    {
        
    
    int number;
    int positive=0, negative=0,count=0; 
    float average;
    int total=0;
    
                                  // below is how to create an ibject
                                 //classname objectnamem = new classname (System.in) e.g see how scanner is created
    
    Scanner Numinput= new Scanner(System.in); //creating an object for scanning class
    
    System.out.println("enter positive or -ve number  but ensure only enter zero if its your last entry");
    
    do
    {
    number=Numinput.nextInt(); 
    total +=number;  //total of numbers is a count of positive and -ves but not zero
    count++;
    if(number > 0)
    {positive++;  //positive count increments
    }
    
    else if(number < 0)
    {negative++;   // negative count increments
    }
}
while(number != 0);// once u enter zero condition terminates

average = total/(count-1); // bse zero will be counted too yet its not part of average

    System.out.println("negative numbers ammount to="+negative);
    System.out.println("\n");
    
    System.out.println("positive numbers ammount to="+positive);
    System.out.println("\n");
    
    System.out.println("average of eneterd numbers is="+average);
    System.out.println("\n");
    
    System.out.println("summation of entered numbers is="+total);
    System.out.println("\n");
        
}
}