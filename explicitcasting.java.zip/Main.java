

//java program to perform explicit data typcaasting i.e high to low

import java.util.Scanner;
public class MAIN
{
    public static void main(String args[])
    {
      
    double joules= 986.665672456;
    
    float area=(float)joules; // target data type must be put in bracket then the old one outside
    
    long speed=(long)area;
    
    int weight=(int)area;
    
    short density=(short)weight;
    
    byte peter=(byte)density;
    
         
    System.out.println("double data type for joules ="+joules + "J");
    System.out.println("\n"); 
    
    System.out.println("float data for area="+area +"M2");
    System.out.println("\n"); 
    
    System.out.println("long data for area ="+area + "cm2");
    System.out.println("\n"); 
    
    System.out.println("int  data weight ="+weight + "kg");
    System.out.println("\n"); 
    
    System.out.println("short data for density ="+density + "cm3");
    System.out.println("\n"); 
    
    System.out.println("byte data for peter="+peter + "kg");
    System.out.println("\n"); 
    
    

}
}